package anillo;

public class Ring {
    public Ring next() {
        return null;
    }

    public Object current() {
        return null;
    }

    public Ring add( Object cargo ) {
        return null;
    }

    public Ring remove() {
        return null;
    }
}
